# 🧠 SkillOps Starter Kit
*A lightweight framework to help you prototype, share, and evolve Agent Skills inspired by Anthropic’s Claude.*

### 🔍 What This Is
This starter kit lets you **build and test “Skills”** — modular folders of instructions, code, and resources that an AI agent (like Claude) can discover, load, and use autonomously.

### 🧩 Folder Structure
```
/skills-library/
 ├── registry.json
 ├── /meeting_summarizer/
 │    ├── SKILL.md
 │    └── /scripts/summarize.py
 └── /finance_report/
      ├── SKILL.md
      └── /scripts/generate_report.py
```

### ⚙️ How to Use
1. Clone or download the repo.
2. Duplicate a Skill folder and edit `SKILL.md`.
3. Test it in Claude.
4. Register it in `registry.json`.
5. Iterate and improve — that’s your first SkillOps loop.

Built by [Work3](https://work3.substack.com/). MIT License.
