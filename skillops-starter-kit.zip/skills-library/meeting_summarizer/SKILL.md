# Skill: Meeting Summarizer

description: Summarize meeting notes into key decisions and next steps.
usage: Use this Skill when given unstructured meeting transcripts or notes.
owner: Matteo Cellini
version: 1.0
last_updated: 2025-10-20

steps:
  - Identify main discussion topics
  - Extract key decisions
  - List follow-up actions
  - Format output as bullet points

tools:
  - summarize.py: Formats bullet-point summaries from extracted notes
