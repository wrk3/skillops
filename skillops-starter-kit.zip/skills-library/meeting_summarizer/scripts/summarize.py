def format_summary(points):
    return "\n".join([f"• {p}" for p in points])
