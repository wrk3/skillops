# Skill: Finance Report

description: Generate a structured financial report from raw data.
usage: When asked to analyze or summarize financial statements.
owner: Chiara Rossi
version: 0.3
last_updated: 2025-09-18

steps:
  - Load data from spreadsheets or CSVs
  - Calculate quarterly metrics
  - Identify anomalies or deltas
  - Produce summary table and narrative

tools:
  - generate_report.py: Processes data and builds formatted outputs
