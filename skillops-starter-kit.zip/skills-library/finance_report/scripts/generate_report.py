def generate_report(data):
    summary = []
    for key, value in data.items():
        summary.append(f"{key}: {value}")
    return "\n".join(summary)
